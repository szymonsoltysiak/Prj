#ifndef FILTRY_H
#define FILTRY_H
#include"struktura.h"

void negatyw(t_obraz*);
void progowanie(t_obraz*,int);
void konturowanie(t_obraz*);
void rozmycie(t_obraz*);
void zmiana_poziomow(t_obraz*, int,int);

#endif