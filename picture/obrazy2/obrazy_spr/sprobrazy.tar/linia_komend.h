#ifndef LINIA_KOMEND_H
#define LINIA_KOMEND_H

#include"struktura.h"

void wyzeruj_opcje(t_opcje *);
int przetwarzaj_opcje(int, char **, t_opcje *); 

#endif